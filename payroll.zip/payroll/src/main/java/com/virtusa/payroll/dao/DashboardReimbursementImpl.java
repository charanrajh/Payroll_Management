package com.virtusa.payroll.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.payroll.Helper.MySQLHelper;

public class DashboardReimbursementImpl implements DashboardReimbursementDao{
	Connection conn;
	ResultSet rs;
	Statement st;
	private CallableStatement callable;
	@Override
	public List<String> getreimbursementAmount(int employeeId) throws SQLException {
		conn=MySQLHelper.getConnection();
        List<String> reimbursement = new ArrayList<String>();
        try {
            callable=conn.prepareCall("{call getReimbursementAmount(?,?,?,?)}"); //getReimbursementAmount
            callable.setInt(1, employeeId);
            System.out.println("1");
            callable.registerOutParameter(2,Types.INTEGER);
            System.out.println("2");
            callable.registerOutParameter(3,Types.DOUBLE);
            callable.registerOutParameter(4,Types.VARCHAR);
            System.out.println("3");
            callable.execute();
           
             reimbursement.add(callable.getInt(2) + "");
             reimbursement.add(callable.getDouble(3) + "");  
             reimbursement.add(callable.getString(4) + "");  
             
             System.out.println(reimbursement.get(2));
           
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        finally {
        	conn.close();
        }
        System.out.println(reimbursement.get(0));
		return reimbursement;
	}
	@Override
	public String getEmployeeName(int employeeId) throws SQLException {
		// TODO Auto-genera
		String employeeName = null;
		conn=MySQLHelper.getConnection();
       
        try {
        	callable=conn.prepareCall("{call getEmployeeName(?,?)}");
            callable.setInt(1, employeeId);
            callable.registerOutParameter(2, Types.VARCHAR);
            callable.execute();
           
            employeeName = callable.getString(2) + "";
        } catch (SQLException e) {
            // TODO Auto-generated catch block
        	System.out.println("Connection problem");
            e.printStackTrace();
        }
        finally {
        	conn.close();
        }
        
		return employeeName;
		
		
	}
	

	
}
