package com.virtusa.payroll.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.payroll.Helper.MySQLHelper;
import com.virtusa.payroll.models.AdminRequestReceivedModel;
import com.virtusa.payroll.models.AdminRequestrResponseModel;

public class AdminRequestResponseImpl implements AdminRequestResponseDao{
	Connection conn;
	ResultSet rs;
	Statement st;
	ResultSetMetaData rsmd;
	private CallableStatement callable;
	@Override
	public List<AdminRequestrResponseModel> getRequestsDetail(int employeeId) throws SQLException {
		// TODO Auto-generated method stub
		conn=MySQLHelper.getConnection();
        List<AdminRequestrResponseModel> reimbursementResponse = new ArrayList<AdminRequestrResponseModel>();
        try {
            callable=conn.prepareCall("{call getEmployeeRequestDetail(?)}"); //getRequestReceivedFromEmployee
            callable.setInt(1, employeeId);
            rs = callable.executeQuery();
            
              
            AdminRequestrResponseModel responseDetail = null;
            
       
    
             while(rs.next()) {
            	 responseDetail = new AdminRequestrResponseModel();
            	 responseDetail.setClaimedAmount(rs.getFloat(1));
            	 responseDetail.setReimbursementtype(rs.getString(2));
            	 
            	 reimbursementResponse.add(responseDetail);
             }
           
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        finally {
        	conn.close();
        }
        return reimbursementResponse;
	
	}
	@Override
	public boolean approveUpdate(int employeeId) throws SQLException {
		// TODO Auto-generated method stub
		conn=MySQLHelper.getConnection();
		boolean b = false;
		try {
            callable=conn.prepareCall("{call statusUpdateApprove(?)}"); //getRequestReceivedFromEmployee
            callable.setInt(1, employeeId);
            b= callable.execute();
            
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        finally {
        	conn.close();
        }
		return b;
	}
	@Override
	public boolean declineUpdate(int employeeId) throws SQLException {
		// TODO Auto-generated method stub
		conn=MySQLHelper.getConnection();
		boolean b = false;
		try {
            callable=conn.prepareCall("{call statusUpdateDeclined(?)}"); //getRequestReceivedFromEmployee
            callable.setInt(1, employeeId);
            b= callable.execute();
            
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        finally {
        	conn.close();
        }
		return b;
	}

}
