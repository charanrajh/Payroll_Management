package com.virtusa.payroll.models;

public class AdminRequestReceivedModel {
	private int employeeId;
	private String name;
	private int reimbursementId;
	private double totalAmount;
	public AdminRequestReceivedModel(int employeeId, String name, int reimbursementId, double totalAmount) {
		super();
		this.employeeId = employeeId;
		this.name = name;
		this.reimbursementId = reimbursementId;
		this.totalAmount = totalAmount;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getReimbursementId() {
		return reimbursementId;
	}
	public void setReimbursementId(int reimbursementId) {
		this.reimbursementId = reimbursementId;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}


}
