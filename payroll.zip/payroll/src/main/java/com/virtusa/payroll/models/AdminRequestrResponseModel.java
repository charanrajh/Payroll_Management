package com.virtusa.payroll.models;

public class AdminRequestrResponseModel {
	private String reimbursementtype;
	private float claimedAmount;
	public String getReimbursementtype() {
		return reimbursementtype;
	}
	public void setReimbursementtype(String reimbursementtype) {
		this.reimbursementtype = reimbursementtype;
	}
	public double getClaimedAmount() {
		return claimedAmount;
	}
	public void setClaimedAmount(float claimedAmount) {
		this.claimedAmount = claimedAmount;
	}
	
	
}
