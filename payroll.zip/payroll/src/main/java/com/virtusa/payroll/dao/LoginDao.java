package com.virtusa.payroll.dao;


import java.sql.SQLException;

public interface LoginDao {
	 boolean validateUser(int userId, String password) throws SQLException;
	 String getNameInSession(int userId);
}
