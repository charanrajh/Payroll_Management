package com.virtusa.payroll.dao;

import java.sql.SQLException;
import java.util.List;

import com.virtusa.payroll.models.AdminRequestReceivedModel;
import com.virtusa.payroll.models.AdminRequestrResponseModel;

public interface AdminRequestResponseDao {
	List<AdminRequestrResponseModel>getRequestsDetail(int employeeId) throws SQLException;
	boolean approveUpdate(int employeeId) throws SQLException;
	boolean declineUpdate(int employeeId) throws SQLException;
}
