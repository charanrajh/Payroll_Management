package com.virtusa.payroll.dao;

import java.sql.SQLException;
import java.util.List;
public interface DashboardReimbursementDao {
	List<String> getreimbursementAmount(int employeeId) throws SQLException;
	String getEmployeeName(int employeeId)throws SQLException;
}
