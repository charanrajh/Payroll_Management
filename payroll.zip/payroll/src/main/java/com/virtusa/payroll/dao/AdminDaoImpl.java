package com.virtusa.payroll.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.payroll.Helper.MySQLHelper;
import com.virtusa.payroll.models.AdminRequestReceivedModel;

public class AdminDaoImpl implements AdminDao {
	Connection conn;
	ResultSet rs;
	Statement st;
	ResultSetMetaData rsmd;
	private CallableStatement callable;
	
	@Override
	public List<AdminRequestReceivedModel> getRequestDetails() throws SQLException {
		// TODO Auto-generated method stub
		conn=MySQLHelper.getConnection();
        List<AdminRequestReceivedModel> reimbursement = new ArrayList<AdminRequestReceivedModel>();
        try {
            callable=conn.prepareCall("{call getAdminRequestDetail2()}"); //getRequestReceivedFromEmployee
            rs = callable.executeQuery();
            
               
            AdminRequestReceivedModel a = null;
            
       
            double sum = 0;
            int nextVal = 0, count = 0;
            while(rs.next()) {
            	nextVal = rs.getInt(3);
            	break;
            }
          rs.beforeFirst();

          String name ="";
          int claimId = 0, m = 0;
           while(rs.next()) {
        	   m = 0;
            	if(nextVal == rs.getInt(3)) {
            		sum += rs.getFloat(2); 
            		count++;
            	    name = rs.getString(1);
            		claimId = rs.getInt(4);
            	}
            	else {    //int employeeNumber, String name, int claimId, double totalAmount
            		a = new AdminRequestReceivedModel(nextVal, name, claimId, sum);
            		reimbursement.add(a);
            		count = 0;
            		sum = 0;
            		m++;
            		sum += rs.getFloat(2);
            		  name = rs.getString(1);
            		  claimId = rs.getInt(4);
            		nextVal = rs.getInt(3);
            	}
            }
           if(count != 0 || m != 0) {
  			 rs.last();
  			 name = rs.getString(1);
      		 claimId = rs.getInt(4);
      		a = new AdminRequestReceivedModel(nextVal, name, claimId, sum);
      		reimbursement.add(a);

  		}
           
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        finally {
        	conn.close();
        }
        return reimbursement;
	}
	

}
