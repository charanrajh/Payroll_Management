package com.virtusa.payroll.Helper;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

/**
 * @author bharathkishore
 *
 */
public class MySQLHelper{

	private static Connection conn;
	public static  Connection getConnection() {
		ResourceBundle rb= ResourceBundle.getBundle("com/virtusa/payroll/resources/db");
		System.out.println("Connected...");
		String userName=rb.getString("user");
		String password=rb.getString("password");
		String url=rb.getString("url");
		String driverName=rb.getString("driver");
		try {
			Class.forName(driverName);
			conn=DriverManager.getConnection(url,userName,password);
			System.out.println("Connected...");
		}catch(ClassNotFoundException c) {
			c.printStackTrace();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}
	
}
