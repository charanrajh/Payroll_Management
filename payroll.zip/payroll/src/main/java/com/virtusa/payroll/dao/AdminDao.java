package com.virtusa.payroll.dao;

import java.sql.SQLException;
import java.util.List;
import com.virtusa.payroll.models.*;

public interface AdminDao {
	List<AdminRequestReceivedModel> getRequestDetails() throws SQLException;
}
