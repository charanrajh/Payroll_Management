package com.virtusa.payroll.dao;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



import com.virtusa.payroll.Helper.MySQLHelper;

public class LoginImpl implements LoginDao {
	private Connection conn;
	private ResultSet rs;
	private Statement st;
	private CallableStatement callable;
	@Override
	public boolean validateUser(int employeeId, String password) throws SQLException {
		// TODO Auto-generated method stub
		conn=MySQLHelper.getConnection();
        boolean check= false;
        try {
        	System.out.println(employeeId+" ====  " + password);
            callable=conn.prepareCall("{call validateUser(?,?)}");
            System.out.println("Here1");
            callable.setInt(1, employeeId);
            System.out.println("Here2");
            callable.setString(2, password);
            System.out.println("Here3");
            check =callable.execute();
            System.out.println("Here");
        } catch (SQLException e) {
            // TODO Auto-generated catch block
        	System.out.println("Connection problem");
            e.printStackTrace();
        }
        finally {
        	conn.close();
        }
        System.out.println(check);
        if(check != false) {
        	return true;
        }
		return check;
	}
	@Override
	public String getNameInSession(int userId) {
		// TODO Auto-generated method stub
		return null;
	}

}
