function openNav() {
    document.getElementById("mySidebar").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
  }
  
  /* Set the width of the sidebar to 0 and the left margin of the page content to 0 */
  function closeNav() {
    document.getElementById("mySidebar").style.width = "0";
    document.getElementById("main").style.marginLeft = "0";
  }

  


window.onload = function(){
  const chart =  document.getElementById("barChart");
new Chart(chart, {
    type: 'pie',
    data:{
        labels: ['option1','option2','option3'],
        datasets: [
            {
            backgroundColor: [
                "#3e95cd", "#8e5ea2","#3cba9f",
            ],
            data: [10, 70, 30]
        }]},
    
        // These labels appear in the legend and in the tooltips when hovering different arcs
    options: {
        animation:{
            animateScale:true,
            responsive:true
        },
        legend:{
          position:'right',
          labels:{
            boxWidth:3,
            padding: 20
          }
        }
    }
    
})
}
;
