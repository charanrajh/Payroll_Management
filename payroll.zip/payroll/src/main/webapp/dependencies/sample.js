

const chart =  document.getElementById("lineChart");


var myPieChart = new Chart(chart, {
    type: 'pie',
    data:{
        labels: ['option1','option2','option3'],
        datasets: [
            {
            backgroundColor: [
                "#3e95cd", "#8e5ea2","#3cba9f",
            ],
            data: [10, 70, 30]
        }]},
    
        // These labels appear in the legend and in the tooltips when hovering different arcs
    options: {
        animation:{
            animateScale:true,
            responsive:true
        }
    }
    
});
